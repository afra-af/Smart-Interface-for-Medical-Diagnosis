document.querySelector('.img-btn').addEventListener('click', function()
	{
		document.querySelector('.cont').classList.toggle('s-signup')
	}
);

document.getElementById("signup-form").addEventListener("submit",(event)=>{
  event.preventDefault()
})





